#include <stdio.h>                                                                        
                                                                                          
int main(void) {                                                                          
	int i;                                                                            
                                                                                          
                                                                                          
	for(i=1;i<=5;i++) {                                                               
		printf("%d\n", i); // i�� ���� ����Ѵ�.                                      
	}                                                                                 
                                                                                          
	for(i=1;i<=5;i++) {                                                               
		printf("%d", i);   // ���๮��'\n'�� ���� ���η� ��µȴ�.                         
	}                                                                                 
	printf("\n");                                                                     
                                                                                          
	return 0;                                                                         
}                                                                                         
