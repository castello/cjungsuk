#include <stdio.h>                                       
                                                         
int main(void) {                                         
	int i= 5;                                        
                                                         
	while(i--) {   // while(i--!=0)                  
		printf("%d - I can do it.\n", i);        
	}                                                
	return 0;                                        
}                                                        
