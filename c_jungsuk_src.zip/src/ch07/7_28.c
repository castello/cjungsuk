#include <stdio.h>                   
                                     
int main(void) {                     
	char chArr[10];                 
	char *ps = "ABC";               
	int  i = 0;                     
                                     
   /*                                
        �˸��� ������ �־� ������ �ϼ��Ͻÿ�.  
   */                                
                                     
	printf("chArr=%s\n", chArr);    
	return 0;                       
}                                    
