int  multiply(int x, int y);                 
int  getUserInput(void);                     
void printGugudan(int dan);                  
void printGugudanAll(void);                  
                                             
