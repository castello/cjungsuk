#include <stdio.h>                
                                  
int main(void) {                  
	char ch = 'A';            
                                  
	printf("ch=%c\n", ch);    
	printf("ch=%d\n", ch);    
                                  
	return 0;                 
}                                 
