#include <stdio.h>                         
                                           
int main(void) {                           
	double d = 85.4;                   
	int score = (int)d;                
                                           
	printf("score=%d\n", score);       
	printf("d=%f\n", d);               
                                           
	return 0;                          
}                                          
