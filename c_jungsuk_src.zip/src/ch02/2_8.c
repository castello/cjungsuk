#include <stdio.h>                            
                                              
int main(void) {                              
	int num;                                 
                                              
	printf("������ �Է��� �ּ���>");               
	scanf("%d", &num);                       
                                              
	printf("�Է��Ͻ� ���ڴ� %d�Դϴ�.\n", num);    
                                              
	return 0;                                
}                                             
