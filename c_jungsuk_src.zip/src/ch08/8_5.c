#include <stdio.h>                                    
                                                      
 /*                                                   
	�� �Լ� swapStr�� �����Ͻÿ�.                          
 */                                                   
                                                      
int main(void) {                                      
	char* str1 = "ABC";                              
	char* str2 = "123";                              
                                                      
	printf("str1=%s, str2=%s\n", str1, str2);        
                                                      
  /*                                                  
	�� ���⿡ ������ ������ swapStr�Լ��� ȣ���ϴ� ������ �����ÿ�. 
  */                                                  
                                                      
	printf("str1=%s, str2=%s\n", str1, str2);        
                                                      
	return 0;                                        
}                                                     
