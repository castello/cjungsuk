#include <stdio.h>                                          
#include <stdlib.h>                                         
#include <string.h>                                         
                                                            
char* toUpperCase(char* str) {                              
  /* �ڵ带 �־� �ϼ��Ͻÿ�. */                                   
}                                                           
                                                            
int main(void) {                                            
	printf("%s -> %s\n", "abc",    toUpperCase("abc"));    
	printf("%s -> %s\n", "a1b2c3", toUpperCase("a1b2c3")); 
                                                            
	return 0;                                              
}                                                           
