#include <stdio.h>                                                               
                                                                                 
int main(void) {                                                                 
	int i=5;                                                                 
	i++;		      // ++i;�� �ٲ� �ᵵ ����� ����.                         
	printf("i=%d\n", i);                                                     
                                                                                 
	i=5;		      // ����� ���ϱ� ���� i���� �ٽ� 5�� ����.                 
	++i;                                                                     
	printf("i=%d\n", i);                                                     
                                                                                 
	return 0;                                                                
}                                                                                
