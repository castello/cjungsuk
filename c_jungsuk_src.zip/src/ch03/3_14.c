#include <stdio.h>                                                    
                                                                      
int main(void) {                                                      
	double pi = 3.141592;                                         
	double shortPi = (                 );  // �� ���� �ڵ�� ä��ÿ�.  
                                                                      
	printf("%lf\n", shortPi);                                     
                                                                      
	return 0;                                                     
}                                                                     
