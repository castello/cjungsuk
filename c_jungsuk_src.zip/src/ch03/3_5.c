#include <stdio.h>                               
                                                 
int main(void) {                                 
	int i=5, j=5;                            
                                                 
	printf("i=%d\n", i++);	                 
	printf("j=%d\n", ++j);                   
	printf("i=%d, j=%d\n", i, j);            
                                                 
	return 0;                                
}                                                
