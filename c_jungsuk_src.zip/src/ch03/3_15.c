#include <stdio.h>                                                        
                                                                          
int main(void) {                                                          
	int x = 10, y = 8;                                                
                                                                          
	printf("%d�� %d�� ������, \n", x, y);                                
	printf("���� %d�̰�, �������� %d�Դϴ�.\n", x / y, x % y);               
                                                                          
	return 0;                                                         
}                                                                         
